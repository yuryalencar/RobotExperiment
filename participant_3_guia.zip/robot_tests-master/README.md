- Início: 18h06
- Término: 20h10

## Observações
- Primeiramente, gostaria de agradecer pelo convite. Por mais que teste de software não seja a minha área,
gostei bastante do framework Robot. Foi bastante agradável escrever casos de teste com ele, que possui um
feeling bem diferente de outras ferramentas, como JUnit, focando muito mais no que fazer ao invés de como
fazer, poupando bastante tempo do programador. 
- Consegui fazer o primeiro caso de teste com certa facilidade, porém, a partir do segundo, tive algumas
dificuldades, tanto pela extensa lista de tarefas quanto por não estar devidamente familiar com atributos
do framework. Acredito que, com mais tempo e calma, conseguiria cumprir com todos. 