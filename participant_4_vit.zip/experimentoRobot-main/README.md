

2 horas e 15 minutos na primeira questão.
Não consegui terminar as restantes.